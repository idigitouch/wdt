
<?php

include "../koneksi.php";
	/*if($m4==0){
	echo"<span class='label label-success'>Success Label</span>";
	}*/
	$id=$_POST['id_terjual'];
	$m1=$_POST['nama_barang'];
	$m2=$_POST['jenis_barang'];
	$m3=$_POST['harga_barang'];
	$m4=$_POST['jumlah_barang'];
	$sub=$m3*$m4;
	$m5=$_POST['tanggal_input'];
  mysql_query("insert into tb_terjual values('$id','$m1','$m2','$m3','$m4','$sub','$m5')");
  header('location:semua-barang.php');
?>
