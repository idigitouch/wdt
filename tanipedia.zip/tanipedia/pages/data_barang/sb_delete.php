<?php
	include"../koneksi.php";
	mysql_query("delete from tb_terjual where id_terjual='$_GET[id]' ");
	header("location:semua-barang.php");
?>
