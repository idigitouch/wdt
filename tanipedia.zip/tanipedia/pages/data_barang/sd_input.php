<?php

include "../koneksi.php";

// Input Pestisida
	$id=$_POST['id_barang'];
	$p1=$_POST['nama_barang'];
	$p2=$_POST['jenis_barang'];
	$p3=$_POST['ukuran'];
	$p4=$_POST['harga_beli'];
	$p5=$_POST['harga_jual'];
	$p6=$_POST['tanggal_input'];
  mysql_query("insert into rb_barang values('$id','$p1','$p2','$p3','$p4','$p5','$p6')");
  header('location:semua-data.php');

?>