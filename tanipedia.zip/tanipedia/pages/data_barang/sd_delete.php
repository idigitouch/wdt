<?php
	include"../koneksi.php";
	mysql_query("delete from rb_barang where id_barang='$_GET[id]' ");
	header("location:semua-data.php");
?>
